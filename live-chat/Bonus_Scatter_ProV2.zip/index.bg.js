// ====== BACKGROUND SWITCHER untuk index.html ======
// Dipisah ke file ini karena CSP ekstensi melarang inline script

const BG_PRESETS_INDEX = {
  default: 'url("https://images.unsplash.com/photo-1528164344705-47542687000d?q=80&w=2092&auto=format&fit=crop")',
  fire:    'radial-gradient(920px 420px at 16% -10%, rgba(239,68,68,0.28), transparent 55%), radial-gradient(760px 340px at 82% -25%, rgba(249,115,22,0.22), transparent 60%), #1a0500',
  ocean:   'radial-gradient(920px 420px at 16% -10%, rgba(0,153,204,0.3), transparent 55%), radial-gradient(760px 340px at 82% -25%, rgba(0,204,255,0.22), transparent 60%), #00101a',
  forest:  'radial-gradient(920px 420px at 16% -10%, rgba(16,185,129,0.28), transparent 55%), radial-gradient(760px 340px at 82% -25%, rgba(5,150,105,0.22), transparent 60%), #00180a',
  galaxy:  'radial-gradient(920px 420px at 16% -10%, rgba(68,0,204,0.35), transparent 55%), radial-gradient(760px 340px at 82% -25%, rgba(204,0,255,0.26), transparent 60%), #05000f',
  gold:    'radial-gradient(920px 420px at 16% -10%, rgba(240,180,41,0.3), transparent 55%), radial-gradient(760px 340px at 82% -25%, rgba(234,179,8,0.24), transparent 60%), #120d00',
  dasha:   'url("./dasha.jpg")',
};

function applyBgIndex(name) {
  const bgLayer   = document.getElementById('bgLayer');
  const bgOverlay = document.getElementById('bgOverlay');
  if (!bgLayer) return;

  const gradient = BG_PRESETS_INDEX[name] || BG_PRESETS_INDEX.default;
  if (gradient.includes('url(')) {
    // If it's an image preset
    bgLayer.style.background = '#000';
    bgLayer.style.backgroundImage = gradient;
    bgLayer.style.backgroundSize = 'cover';
    bgLayer.style.backgroundPosition = 'center';
    bgLayer.style.backgroundRepeat = 'no-repeat';
    document.documentElement.style.setProperty('--dasha-img', gradient);
    if (bgOverlay) bgOverlay.style.background = 'rgba(0,0,0,0.4)';
  } else {
    // If it's a gradient preset
    bgLayer.style.background = gradient;
    bgLayer.style.backgroundImage = '';
    if (bgOverlay) bgOverlay.style.background = 'rgba(0,0,0,0)';
  }

  document.querySelectorAll('.bgBtn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.bg === name);
  });

  if (name === 'default' || name === 'custom') {
    startLeafAnimation();
  } else {
    stopLeafAnimation();
  }
}

let leafInterval = null;
function startLeafAnimation() {
  if (leafInterval) return;
  const emojis = ['🍁', '🍂', '🌸'];
  const maxLeaves = 25;
  leafInterval = setInterval(() => {
    if (document.querySelectorAll('.leaf').length > maxLeaves) return;
    const leaf = document.createElement('div');
    leaf.className = 'leaf';
    leaf.innerText = emojis[Math.floor(Math.random() * emojis.length)];
    leaf.style.left = Math.random() * 100 + 'vw';
    const duration = Math.random() * 3 + 4; // 4 to 7 seconds
    leaf.style.animationDuration = duration + 's, ' + (duration / 2) + 's';
    leaf.style.fontSize = (Math.random() * 10 + 15) + 'px';
    document.body.appendChild(leaf);
    setTimeout(() => {
      if (leaf.parentNode) leaf.remove();
    }, duration * 1000);
  }, 300);
}

function stopLeafAnimation() {
  if (leafInterval) clearInterval(leafInterval);
  leafInterval = null;
  document.querySelectorAll('.leaf').forEach(l => l.remove());
}

function applyCustomBgIndex(dataUrl) {
  const bgLayer   = document.getElementById('bgLayer');
  const bgOverlay = document.getElementById('bgOverlay');
  if (!bgLayer) return;

  bgLayer.style.background         = '#000';
  bgLayer.style.backgroundImage    = 'url(' + dataUrl + ')';
  bgLayer.style.backgroundSize     = 'cover';
  bgLayer.style.backgroundPosition = 'center';
  bgLayer.style.backgroundRepeat   = 'no-repeat';
  if (bgOverlay) bgOverlay.style.background = 'rgba(0,0,0,0.58)';

  document.querySelectorAll('.bgBtn').forEach(btn => btn.classList.remove('active'));
}

// Load preference tersimpan
try {
  chrome.storage.local.get(['bsBgTheme', 'bsBgCustom'], function(res) {
    if (res.bsBgCustom) {
      applyCustomBgIndex(res.bsBgCustom);
    } else {
      applyBgIndex(res.bsBgTheme || 'default');
    }
  });
} catch(e) {
  // fallback jika bukan extension page
  applyBgIndex('default');
}

// Klik tema
document.querySelectorAll('.bgBtn').forEach(function(btn) {
  btn.addEventListener('click', function() {
    var theme = btn.dataset.bg;
    applyBgIndex(theme);
    var bgLayer = document.getElementById('bgLayer');
    if (bgLayer) bgLayer.style.backgroundImage = '';
    try {
      chrome.storage.local.set({ bsBgTheme: theme, bsBgCustom: null });
    } catch(e) {}
  });
});

// Upload foto
var uploadBtn    = document.querySelector('.bgUploadBtn');
var bgImageInput = document.getElementById('bgImageInput');

if (uploadBtn && bgImageInput) {
  uploadBtn.addEventListener('click', function() {
    bgImageInput.click();
  });

  bgImageInput.addEventListener('change', function(e) {
    var file = e.target.files && e.target.files[0];
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function(ev) {
      var dataUrl = ev.target.result;
      applyCustomBgIndex(dataUrl);
      try {
        chrome.storage.local.set({ bsBgCustom: dataUrl, bsBgTheme: 'custom' });
      } catch(err) {
        console.warn('BG image terlalu besar:', err);
      }
    };
    reader.readAsDataURL(file);
  });
}
