function setNativeValue(el, value) {
  const v = String(value ?? '');
  const proto = Object.getPrototypeOf(el);
  const desc = Object.getOwnPropertyDescriptor(proto, 'value');
  if (desc && typeof desc.set === 'function') {
    desc.set.call(el, v);
  } else {
    el.value = v;
  }
  el.dispatchEvent(new Event('input', { bubbles: true }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
}

function isVisible(el) {
  if (!el) return false;
  const cs = window.getComputedStyle(el);
  if (!cs) return false;
  if (cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0') return false;
  const r = el.getBoundingClientRect();
  return r.width > 0 && r.height > 0;
}

function x1(path) {
  try {
    return document.evaluate(path, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
  } catch {
    return null;
  }
}

function parseNumberLike(input) {
  const s = String(input ?? '').replace(/,/g, '').trim();
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

function clampBettingValue(n) {
  if (!Number.isFinite(n)) return null;
  const v = Math.trunc(n);
  if (v < 0) return 0;
  return Math.min(v, 9999999);
}

function findInputByPlaceholder(placeholder) {
  return document.querySelector(`input[data-slot="input"][placeholder="${placeholder}"]`) ||
    document.querySelector(`input[placeholder="${placeholder}"]`);
}

function findTextareaByPlaceholder(placeholder) {
  return document.querySelector(`textarea[data-slot="textarea"][placeholder="${placeholder}"]`) ||
    document.querySelector(`textarea[placeholder="${placeholder}"]`);
}

function findScatterSelectRoot() {
  const labels = Array.from(document.querySelectorAll('div'));
  const label = labels.find((d) => String(d.textContent || '').trim() === 'Jumlah Scatter');
  if (!label) return null;
  const row = label.closest('.flex') || label.parentElement;
  if (!row) return null;
  const container = row.querySelector('.css-b62m3t-container') || row.querySelector('[class*="css-"]');
  return container;
}

function findSelectContainerByLabel(labelText) {
  const labels = Array.from(document.querySelectorAll('div'));
  const label = labels.find((d) => String(d.textContent || '').trim() === labelText);
  if (!label) return null;
  const row = label.closest('.flex') || label.parentElement;
  if (!row) return null;
  const container = row.querySelector('.css-b62m3t-container');
  return container || null;
}

async function selectReactSelectValue(container, valueText) {
  if (!container) return false;
  const control = container.querySelector('.select2__control');
  if (!control) return false;
  const ariaDisabled = control.getAttribute('aria-disabled');
  if (ariaDisabled === 'true' || control.className.includes('--is-disabled')) return false;
  control.click();

  const started = Date.now();
  while (Date.now() - started < 3000) {
    const options = Array.from(document.querySelectorAll('div[id^="react-select-"][id*="-option-"]'));
    if (options.length) {
      const target = options.find((o) => String(o.textContent || '').trim().toLowerCase() === String(valueText).trim().toLowerCase());
      if (target) {
        target.click();
        return true;
      }
      return false;
    }
    await sleep(100);
  }
  return false;
}

function sleep(ms) {
  const n = Number(ms || 0);
  const scaled = Math.max(5, Math.round(n * 0.65));
  return new Promise((r) => setTimeout(r, scaled));
}

function dispatchKey(target, key) {
  const ev = new KeyboardEvent('keydown', { bubbles: true, cancelable: true, key, code: key });
  target.dispatchEvent(ev);
}

async function typeValue(el, value) {
  const text = String(value ?? '');
  try { el.focus(); } catch {}
  try {
    el.dispatchEvent(new KeyboardEvent('keydown', { key: 'a', code: 'KeyA', ctrlKey: true, bubbles: true }));
    el.dispatchEvent(new KeyboardEvent('keyup', { key: 'a', code: 'KeyA', ctrlKey: true, bubbles: true }));
  } catch {}
  try {
    el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Backspace', code: 'Backspace', bubbles: true }));
    el.dispatchEvent(new KeyboardEvent('keyup', { key: 'Backspace', code: 'Backspace', bubbles: true }));
  } catch {}
  setNativeValue(el, '');
  await sleep(50);

  for (const ch of text) {
    try {
      el.dispatchEvent(new KeyboardEvent('keydown', { key: ch, code: ch, bubbles: true }));
      el.dispatchEvent(new KeyboardEvent('keypress', { key: ch, code: ch, bubbles: true }));
    } catch {}

    const next = String(el.value || '') + ch;
    setNativeValue(el, next);
    try {
      el.dispatchEvent(new InputEvent('input', { bubbles: true, data: ch, inputType: 'insertText' }));
    } catch {}

    try {
      el.dispatchEvent(new KeyboardEvent('keyup', { key: ch, code: ch, bubbles: true }));
    } catch {}
    await sleep(60);
  }

  try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch {}
  await sleep(80);
  try { el.blur(); } catch {}
}

function getComboboxTarget(container) {
  if (!container) return null;
  return (
    container.querySelector('input[id^="react-select-"][id$="-input"]') ||
    container.querySelector('input.select2__input') ||
    container.querySelector('[role="combobox"]') ||
    container.querySelector('input')
  );
}

async function openReactSelect(container) {
  if (!container) return false;
  const control = container.querySelector('.select2__control');
  if (!control) return false;
  const ariaDisabled = control.getAttribute('aria-disabled');
  if (ariaDisabled === 'true' || control.className.includes('--is-disabled')) return false;
  control.click();
  await sleep(80);
  const target = getComboboxTarget(container);
  if (target) {
    try { target.focus(); } catch {}
  }
  return true;
}

async function selectByKeyboard(container, { down = 1, up = 0 } = {}) {
  const opened = await openReactSelect(container);
  if (!opened) return false;
  const target = getComboboxTarget(container) || container;
  for (let i = 0; i < down; i++) {
    dispatchKey(target, 'ArrowDown');
    await sleep(60);
  }
  for (let i = 0; i < up; i++) {
    dispatchKey(target, 'ArrowUp');
    await sleep(60);
  }
  dispatchKey(target, 'Enter');
  await sleep(80);
  return true;
}

function findTambahDataTrigger() {
  const triggers = Array.from(document.querySelectorAll('button[data-slot="dialog-trigger"], [data-slot="dialog-trigger"]'));
  const bySlot = triggers.find((el) => isVisible(el));
  if (bySlot) return bySlot;

  const keywords = ['tambah data', 'tambah', 'add', 'create', 'new', 'buat'];

  const buttons = Array.from(document.querySelectorAll('button'));
  const matchBtn = buttons.find((el) => {
    const t = String(el.textContent || '').trim().toLowerCase();
    if (!t) return false;
    if (!isVisible(el)) return false;
    return keywords.some((k) => t.includes(k));
  });
  if (matchBtn) return matchBtn;

  const labelled = buttons.find((el) => {
    const aria = String(el.getAttribute('aria-label') || '').trim().toLowerCase();
    const title = String(el.getAttribute('title') || '').trim().toLowerCase();
    if (!isVisible(el)) return false;
    return keywords.some((k) => aria.includes(k) || title.includes(k));
  });
  if (labelled) return labelled;

  const divs = Array.from(document.querySelectorAll('div'));
  const matchDiv = divs.find((el) => {
    const t = String(el.textContent || '').trim().toLowerCase();
    if (!t) return false;
    if (!isVisible(el)) return false;
    return keywords.some((k) => t.includes(k));
  });
  if (matchDiv) return matchDiv.closest('button') || matchDiv;
  return null;
}

async function ensureFormOpen() {
  const bodyText = String(document.body && document.body.innerText ? document.body.innerText : '');
  const looksLikeLanding = bodyText.includes('Setiap hari adalah peluang baru') || bodyText.includes('SMBGROUP');
  if (looksLikeLanding) return false;

  const hasFormTitle = () => {
    const title = Array.from(document.querySelectorAll('div')).find((d) => String(d.textContent || '').trim() === 'Form Tiket');
    return !!title;
  };

  if (hasFormTitle()) return true;

  const started = Date.now();
  let clicked = false;
  while (Date.now() - started < 20000) {
    if (hasFormTitle()) return true;
    const userInput = findInputByPlaceholder('User ID');
    const kodeInput = findInputByPlaceholder('Kode Tiket');
    if (userInput && kodeInput && isVisible(userInput) && isVisible(kodeInput)) return true;

    const trigger = findTambahDataTrigger();
    if (trigger && isVisible(trigger)) {
      try { trigger.scrollIntoView({ block: 'center' }); } catch {}
      try { trigger.click(); } catch {}
      clicked = true;
    }

    if (!clicked && Date.now() - started > 4000) {
      try { window.scrollTo({ top: 0, behavior: 'instant' }); } catch {
        try { window.scrollTo(0, 0); } catch {}
      }
    }

    await sleep(250);
  }
  return false;
}

function getFormElement() {
  const titleEl = Array.from(document.querySelectorAll('div')).find((d) => String(d.textContent || '').trim() === 'Form Tiket');
  if (titleEl) {
    const root = titleEl.closest('[role="dialog"]') || titleEl.closest('div');
    const form = root ? root.querySelector('form') : null;
    if (form) return form;
  }
  const formFallback = Array.from(document.querySelectorAll('form')).find((f) => {
    const t = String(f.textContent || '');
    return t.includes('User ID') && t.includes('Kode Tiket');
  });
  return formFallback || null;
}

function getControlsFromForm(formEl) {
  if (!formEl) return { situs: null, tipe: null, scatter: null, saveBtn: null };
  const containers = Array.from(formEl.querySelectorAll('.css-b62m3t-container'));
  const situs = containers[0] || null;
  const tipe = containers[1] || null;

  const scatterLabel = Array.from(formEl.querySelectorAll('div')).find((d) => String(d.textContent || '').trim() === 'Jumlah Scatter');
  const scatterRow = scatterLabel ? (scatterLabel.closest('.flex') || scatterLabel.parentElement) : null;
  const scatter = scatterRow ? scatterRow.querySelector('.css-b62m3t-container') : null;

  const btns = Array.from(formEl.querySelectorAll('button'));
  const saveBtn = btns.find((b) => String(b.textContent || '').trim().toLowerCase() === 'simpan') ||
    btns.find((b) => b.getAttribute('data-slot') === 'button') ||
    null;

  return { situs, tipe, scatter, saveBtn };
}

function findSaveButton(formEl) {
  const root = (formEl && (formEl.closest('[role="dialog"]') || formEl.closest('div'))) || document;
  const buttons = Array.from(root.querySelectorAll('button'));
  const isClickable = (b) => {
    if (!b) return false;
    if (b.disabled) return false;
    const ariaDisabled = b.getAttribute('aria-disabled');
    if (ariaDisabled === 'true') return false;
    return isVisible(b);
  };
  const byText = buttons.find((b) => isClickable(b) && String(b.textContent || '').trim().toLowerCase() === 'simpan');
  if (byText) return byText;
  const bySlot = buttons.find((b) => isClickable(b) && b.getAttribute('data-slot') === 'button');
  if (bySlot) return bySlot;
  const byType = buttons.find((b) => isClickable(b) && b.getAttribute('type') === 'submit');
  if (byType) return byType;
  return null;
}

async function waitForTicketSaveResponse(timeoutMs) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const text = String(document.body && document.body.innerText ? document.body.innerText : '');
    if (text.includes('The ticket code has already been taken.')) {
      return { ok: false, code: 'ticket_taken', error: 'The ticket code has already been taken.' };
    }
    if (text.toLowerCase().includes('already been taken')) {
      return { ok: false, code: 'ticket_taken', error: 'The ticket code has already been taken.' };
    }
    await sleep(150);
  }
  return { ok: true };
}

async function waitForOptions(timeout = 500) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const opts = Array.from(document.querySelectorAll('[role="option"], .select2__option'))
      .filter((o) => o && o.offsetParent !== null);
    if (opts.length > 0) return opts;
    await sleep(5);
  }
  return [];
}

async function clickArrowDownAndSelect(ctrl) {
  try {
    if (!ctrl) return false;
    const control = ctrl.querySelector('.select2__control') || ctrl;
    const ariaDisabled = control.getAttribute('aria-disabled');
    if (ariaDisabled === 'true' || String(control.className || '').includes('--is-disabled')) return false;
    control.click();
    await sleep(80);

    const inner = control.querySelector('input, [role="combobox"]');
    const target = inner || control;
    if (inner) {
      try { inner.focus(); } catch {}
    }
    target.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true }));
    await sleep(120);

    const opts = await waitForOptions(800);
    if (opts.length) {
      opts[0].click();
      return true;
    }
  } catch {}
  return false;
}

async function waitForActive(el, timeout = 1500) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    if (el && el.offsetParent !== null) {
      const control = el.querySelector('.select2__control') || el;
      const ariaDisabled = control.getAttribute('aria-disabled');
      if (ariaDisabled !== 'true' && !String(control.className || '').includes('--is-disabled')) return true;
    }
    await sleep(20);
  }
  return false;
}

async function fillScatterByKeyboard(container, scatterValue) {
  if (!container) return false;
  if (!await waitForActive(container, 7000)) return false;

  const control = container.querySelector('.select2__control') || container;
  control.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
  control.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
  control.click();
  await sleep(100);

  const input = container.querySelector('input, [role="combobox"]');
  if (input) {
    try { input.focus(); } catch {}
  }
  const target = input || control;
  const val = parseInt(scatterValue, 10);
  if (val === 3) {
    dispatchKey(target, 'ArrowUp');
    await sleep(80);
    dispatchKey(target, 'ArrowUp');
    await sleep(80);
    dispatchKey(target, 'ArrowUp');
    await sleep(80);
    dispatchKey(target, 'Enter');
    await sleep(80);
    return true;
  }
  if (val === 4) {
    dispatchKey(target, 'ArrowUp');
    await sleep(80);
    dispatchKey(target, 'ArrowUp');
    await sleep(80);
    dispatchKey(target, 'Enter');
    await sleep(80);
    return true;
  }
  if (val === 5) {
    dispatchKey(target, 'ArrowUp');
    await sleep(80);
    dispatchKey(target, 'Enter');
    await sleep(80);
    return true;
  }

  const arrowDownTimes = Math.max(0, val - 3);
  for (let i = 0; i < arrowDownTimes; i++) {
    dispatchKey(target, 'ArrowDown');
    await sleep(120);
  }
  dispatchKey(target, 'Enter');
  await sleep(80);
  return true;
}

function getFieldStateSnapshot() {
  const siteVal = document.querySelector("div:has(> .select2__single-value)");
  const siteText = (() => {
    const el = Array.from(document.querySelectorAll('.select2__single-value')).find((x) => {
      const t = String(x.textContent || '').trim().toLowerCase();
      return t === 'wdbos' || t === 'mahjong' || t.length > 0;
    });
    return el ? String(el.textContent || '').trim() : '';
  })();

  const claimRow = Array.from(document.querySelectorAll('div')).find((d) => String(d.textContent || '').trim() === 'Klaim melalui');
  const claimText = claimRow ? String((claimRow.closest('.flex') || claimRow.parentElement)?.textContent || '').trim() : '';

  const hasBet = !!(document.querySelector('input[type="number"][placeholder="#######"]') || Array.from(document.querySelectorAll('input[type="number"]')).find((i) => i.getAttribute('placeholder') === '#######'));
  const scatterRoot = findScatterSelectRoot();
  const scatterDisabled = scatterRoot ? isScatterDisabled() : true;

  return {
    siteText,
    claimText,
    hasBet,
    hasScatter: !!scatterRoot,
    scatterDisabled,
  };
}

async function selectScatterValue(scatter) {
  const container = findScatterSelectRoot();
  if (!container) return false;
  const desired = String(scatter);
  const byClick = await selectReactSelectValue(container, desired);
  if (byClick) return true;

  const val = parseInt(desired, 10);
  if (val === 3) return selectByKeyboard(container, { up: 3, down: 0 });
  if (val === 4) return selectByKeyboard(container, { up: 2, down: 0 });
  if (val === 5) return selectByKeyboard(container, { up: 1, down: 0 });
  return selectByKeyboard(container, { down: 1, up: 0 });
}

function isScatterDisabled() {
  const root = findScatterSelectRoot();
  if (!root) return true;
  const control = root.querySelector('.select2__control');
  if (!control) return true;
  const ariaDisabled = control.getAttribute('aria-disabled');
  return ariaDisabled === 'true' || control.className.includes('--is-disabled') || root.className.includes('select2--is-disabled');
}

async function waitScatterEnabled(timeoutMs) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    if (!isScatterDisabled()) return true;
    await sleep(200);
  }
  return false;
}

async function fillTicket(payload) {
  const userId = String(payload.userIdRaw || payload.userId || '').trim();
  const kodeTiket = String(payload.transactionId || '').trim();
  const scatterCount = typeof payload.scatterCount === 'number' ? payload.scatterCount : parseNumberLike(payload.scatterCount);
  const debet = clampBettingValue(parseNumberLike(payload.debetValue));

  const opened = await ensureFormOpen();
  if (!opened) {
    const bodyText = String(document.body && document.body.innerText ? document.body.innerText : '');
    const looksLikeLanding = bodyText.includes('Setiap hari adalah peluang baru') || bodyText.includes('SMBGROUP');
    return { ok: false, error: looksLikeLanding ? 'Belum login / bukan halaman Ticket Management' : 'Dialog Form Tiket tidak bisa dibuka' };
  }

  const formEl = getFormElement();
  const { situs, tipe, scatter } = getControlsFromForm(formEl);

  const userInput = (formEl && formEl.querySelector('input[placeholder="User ID"]')) || findInputByPlaceholder('User ID');
  const kodeInput = (formEl && formEl.querySelector('input[placeholder="Kode Tiket"]')) || findInputByPlaceholder('Kode Tiket');
  if (!userInput || !kodeInput) {
    return { ok: false, error: 'Form Tiket tidak ditemukan / selector berubah' };
  }

  if (situs) {
    const ok = await clickArrowDownAndSelect(situs);
    if (!ok) {
      const desiredSite = String(payload.site || 'wdbos');
      await selectReactSelectValue(situs, desiredSite);
    }
    await sleep(100);
  }

  if (tipe) {
    const ok = await clickArrowDownAndSelect(tipe);
    if (!ok) {
      const desiredType = String(payload.gameType || '').trim();
      if (desiredType) await selectReactSelectValue(tipe, desiredType);
    }
    await sleep(100);
  }

  const claimWaitStart = Date.now();
  while (Date.now() - claimWaitStart < 12000) {
    const t = String(document.body && document.body.innerText ? document.body.innerText : '');
    if (!t.includes('Loading konfigurasi klaim')) break;
    await sleep(250);
  }

  const bettingInput = (formEl && formEl.querySelector('input[type="number"][placeholder="#######"]')) ||
    document.querySelector('input[type="number"][placeholder="#######"]') ||
    Array.from(document.querySelectorAll('input[type="number"]')).find((i) => i.getAttribute('placeholder') === '#######');
  const scatterRootNow = scatter || findScatterSelectRoot();
  if (!bettingInput || !scatterRootNow) {
    const missing = [!bettingInput ? 'Bettingan' : null, !scatterRootNow ? 'Jumlah Scatter' : null].filter(Boolean);
    const snap = getFieldStateSnapshot();
    return { ok: false, error: `Field belum muncul: ${missing.join(', ')} | site=${snap.siteText} | scatterDisabled=${snap.scatterDisabled} | claim=${snap.claimText}` };
  }

  setNativeValue(userInput, userId);
  setNativeValue(kodeInput, kodeTiket);
  if (debet !== null) {
    await typeValue(bettingInput, String(debet));
  }

  if (scatterCount !== null) {
    const enabled = await waitScatterEnabled(12000);
    if (!enabled) {
      return { ok: false, error: 'Jumlah Scatter masih terkunci (pastikan bettingan valid & konfigurasi klaim sudah selesai)' };
    }
  }

  if (scatterCount !== null) {
    await new Promise((r) => setTimeout(r, 200));
    const ok = await fillScatterByKeyboard(scatterRootNow, scatterCount);
    if (!ok) {
      await selectScatterValue(scatterCount);
    }
  }

  await sleep(250);
  const saveBtn = findSaveButton(formEl);
  if (saveBtn) {
    try { saveBtn.scrollIntoView({ block: 'center' }); } catch {}
    try { saveBtn.click(); } catch {}
    const resp = await waitForTicketSaveResponse(3000);
    if (!resp.ok) return resp;
    return { ok: true, saved: true };
  }

  return { ok: false, error: 'Tombol Simpan tidak ditemukan / tidak bisa diklik' };
}

function injectRocketSearchButton() {
  if (document.getElementById('rocketSearchBtn')) return;
  if (!document.body) {
    setTimeout(injectRocketSearchButton, 100);
    return;
  }
  
  const btn = document.createElement('div');
  btn.id = 'rocketSearchBtn';
  btn.innerHTML = '🚀';
  btn.style.cssText = `
    position: fixed;
    bottom: 30px;
    right: 30px;
    width: 65px;
    height: 65px;
    background: linear-gradient(135deg, #ffd700, #ff8c00);
    border: 2px solid rgba(255, 255, 255, 0.4);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 35px;
    cursor: pointer;
    box-shadow: 0 0 25px rgba(255, 215, 0, 0.7);
    z-index: 2147483647;
    transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    user-select: none;
  `;
  
  btn.title = 'Roket Pencari Status';
  
  btn.onmouseover = () => btn.style.transform = 'scale(1.1) rotate(-10deg)';
  btn.onmouseout = () => btn.style.transform = 'scale(1) rotate(0deg)';
  
  btn.onclick = async () => {
    btn.style.transform = 'scale(0.8) translateY(-10px)';
    setTimeout(() => btn.style.transform = 'scale(1) translateY(0)', 200);
    
    // Trigger background verification
    chrome.runtime.sendMessage({ type: 'BONUSSMB_TRIGGER_VERIFICATION' });
    
    // Visual feedback
    const originalText = btn.innerHTML;
    btn.innerHTML = '🔍';
    setTimeout(() => btn.innerHTML = originalText, 2000);
  };
  
  document.body.appendChild(btn);
  console.log('[BonusScatter] Rocket button injected.');
}

// Aggressive injection
if (location.href.includes('bonussmb.com')) {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectRocketSearchButton);
  } else {
    injectRocketSearchButton();
  }
  // Also interval check in case of SPA navigation
  setInterval(injectRocketSearchButton, 2000);
}

async function ensureTargetPage(targetUrl) {
  if (location.href.includes(targetUrl)) return true;
  
  const keywords = targetUrl.includes('history') ? ['history', 'riwayat'] : ['ticket', 'tiket'];
  const elements = Array.from(document.querySelectorAll('a, button, [role="button"], span, div.flex'));
  
  const match = elements.find(el => {
    if (!isVisible(el)) return false;
    const t = el.textContent.toLowerCase();
    const href = (el.getAttribute && el.getAttribute('href')) || '';
    return keywords.some(k => t.includes(k) || href.includes(k));
  });

  if (match) {
    console.log('[BonusScatter] Clicking tab:', match.textContent);
    match.click();
    await sleep(1500);
    if (location.href.includes(targetUrl)) return true;
  }

  console.log('[BonusScatter] Hard redirecting to:', targetUrl);
  location.href = targetUrl;
  return false;
}

function getKeteranganValue(foundRow, ticketCode, userId) {
  try {
    // ===== METODE 1: Cari kolom KETERANGAN via header tabel =====
    const table = foundRow.closest('table');
    if (table) {
      // Scan SEMUA baris untuk menemukan header (bisa di thead, bisa di tr pertama)
      const allRows = Array.from(table.querySelectorAll('tr'));
      let ketIdx = -1;
      
      for (const headerRow of allRows) {
        const cells = Array.from(headerRow.querySelectorAll('th, td'));
        for (let i = 0; i < cells.length; i++) {
          const text = cells[i].innerText.toLowerCase().trim();
          if (text.includes('keterangan') || text.includes('note') || text.includes('reason') || text.includes('remark')) {
            ketIdx = i;
            break;
          }
        }
        if (ketIdx >= 0) break;
      }
      
      if (ketIdx >= 0) {
        const dataCells = Array.from(foundRow.querySelectorAll('td'));
        if (dataCells[ketIdx]) {
          const val = dataCells[ketIdx].innerText.trim();
          if (val && val !== '-' && val.length > 1) {
            console.log('🔍 Keterangan found via header index:', ketIdx, '→', val);
            return val;
          }
        }
      }
    }

    // ===== METODE 2: Scan kolom terakhir (Keterangan biasanya di kolom paling kanan) =====
    const dataCells = Array.from(foundRow.querySelectorAll('td'));
    if (dataCells.length > 0) {
      // Cek 2 kolom terakhir (keterangan biasanya di paling kanan)
      for (let i = dataCells.length - 1; i >= Math.max(0, dataCells.length - 3); i--) {
        const val = dataCells[i].innerText.trim();
        if (!val || val === '-' || val.length < 2) continue;
        const lower = val.toLowerCase();
        // Pastikan ini BUKAN status / angka / tanggal
        if (lower === 'approved' || lower === 'rejected' || lower === 'waiting' || lower === 'pending') continue;
        if (/^[\d.,\s]+$/.test(val)) continue; // Murni angka
        if (/^\d{2,4}[-\/]/.test(val)) continue; // Tanggal
        if (lower.startsWith('rp') || lower.includes('idr')) continue; // Uang
        // Ini kemungkinan besar keterangan!
        console.log('🔍 Keterangan found via last-column scan, col', i, '→', val);
        return val;
      }
    }

    // ===== METODE 3: Heuristic filter semua teks di baris =====
    const textElements = Array.from(foundRow.querySelectorAll('td'))
      .map(el => el.innerText.trim())
      .filter(t => t.length > 1);
    
    for (const t of textElements) {
      const lower = t.toLowerCase();
      if (t.length > 100) continue;
      if (t.includes(ticketCode) || ticketCode.includes(t)) continue;
      if (userId && (lower.includes(userId.toLowerCase()) || userId.toLowerCase().includes(lower))) continue;
      if (lower.includes('approved') || lower.includes('rejected') || lower.includes('pending') || 
          lower.includes('waiting') || lower.includes('livechat') || t === '-') continue;
      if (lower.includes('rp') || lower.includes('idr') || lower.startsWith('x') || /^[\d.,x\s+]+$/i.test(t)) continue;
      if (lower.includes('mahjong') || lower.includes('lapak') || lower.includes('wdbos') || lower.includes('slot')) continue;
      if (/\d{2,4}[-\/]\d{2}/.test(t)) continue;
      if (lower.includes(':') && /\d{2}:\d{2}/.test(t)) continue; // Hanya filter waktu, bukan semua teks dengan ':'
      
      console.log('🔍 Keterangan found via heuristic:', t);
      return t;
    }
  } catch (e) {
    console.warn('Gagal ekstrak keterangan:', e);
  }
  return '';
}

async function checkStatusGeneric(payload) {
  const userId = String(payload.userId || '').trim();
  const ticketCode = String(payload.transactionId || '').trim();
  const targetUrl = payload.targetUrl || '';
  
  // Ensure we are on the correct page
  const onTarget = await ensureTargetPage(targetUrl);
  if (!onTarget) return { ok: false, error: 'Redirecting...' };
  await sleep(150);

  // 1. Find search input
  let searchInput = document.querySelector('input[placeholder*="Search"]') || 
                    document.querySelector('input[type="text"]') ||
                    document.querySelector('.search-input input') ||
                    document.querySelector('input[name="search"]');

  if (!searchInput) {
    const ctrlF = Array.from(document.querySelectorAll('kbd, span, div')).find(el => el.textContent.includes('Ctrl F'));
    if (ctrlF) searchInput = ctrlF.parentElement.querySelector('input');
  }

  if (!searchInput) {
    return { ok: false, error: 'Search input not found' };
  }

  // 2. Clear search lama dan ketik kode tiket baru
  console.log('[BonusScatter] Searching ticket:', ticketCode);
  setNativeValue(searchInput, '');
  searchInput.dispatchEvent(new Event('input', { bubbles: true }));
  await sleep(50);

  setNativeValue(searchInput, ticketCode);
  searchInput.dispatchEvent(new Event('input', { bubbles: true }));
  searchInput.dispatchEvent(new Event('change', { bubbles: true }));
  searchInput.focus();
  
  // Trigger search via button or Enter key
  const searchBtn = document.querySelector('button.search-btn') || 
                    Array.from(document.querySelectorAll('button')).find(b => {
                      const t = b.textContent.toLowerCase();
                      return t.includes('search') || t.includes('cari');
                    });
  
  if (searchBtn) {
    searchBtn.click();
  } else {
    ['keydown', 'keypress', 'keyup'].forEach(et => {
      searchInput.dispatchEvent(new KeyboardEvent(et, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    });
  }
  
  await sleep(400);

  // 3. Find the row with the ticket code
  const findRow = () => {
    const allRows = Array.from(document.querySelectorAll('tr, [role="row"], .table-row, .ant-table-row'));
    for (const row of allRows) {
      if (row.innerText.includes(ticketCode)) return row;
    }
    const allElements = document.querySelectorAll('td, span, div, p, a');
    for (const el of allElements) {
      if (el.children.length === 0 && el.innerText.trim() === ticketCode) {
        return el.closest('tr') || el.closest('[role="row"]') || el.parentElement;
      }
    }
    return null;
  };

  let foundRow = findRow();
  
  if (!foundRow) {
    // Fast retry loop: max 5 attempts × 250ms = 1.25s
    for (let i = 0; i < 5; i++) {
      await sleep(250);
      foundRow = findRow();
      if (foundRow) break;
    }
  }

  if (!foundRow) {
    const emptyMsg = 
      document.querySelector('.ant-empty-description') || 
      document.querySelector('.no-data') ||
      Array.from(document.querySelectorAll('div, span, p')).find(el => {
        const t = el.innerText;
        return t.includes('out of 0') || t.includes('No data') || t.includes('tidak ditemukan');
      });

    if (emptyMsg) {
      return { ok: true, status: 'NOT_FOUND', detail: 'Tiket tidak ditemukan di web' };
    }

    return { ok: false, error: 'Row not found on page' };
  }

  // 4. Extract status
  const fullRowText = foundRow.innerText.toUpperCase();
  let status = 'PENDING';
  
  if (fullRowText.includes('APPROVED') || fullRowText.includes('SUKSES') || fullRowText.includes('BERHASIL') || fullRowText.includes('DITERIMA')) {
    status = 'APPROVED';
  } else if (fullRowText.includes('REJECTED') || fullRowText.includes('TOLAK') || fullRowText.includes('GAGAL')) {
    status = 'REJECTED';
  } else if (fullRowText.includes('WAITING') || fullRowText.includes('PROCESS') || fullRowText.includes('ANTRI') || fullRowText.includes('MENUNGGU')) {
    status = 'WAITING';
  } else if (fullRowText.includes('PENDING')) {
    status = 'PENDING';
  }

  console.log('[BonusScatter] Found Status:', status, 'for ticket:', ticketCode);
  return { ok: true, status, keterangan: status === 'REJECTED' ? getKeteranganValue(foundRow, ticketCode, userId) : '' };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== 'object') return;
  if (msg.type === 'BONUSSMB_PING') {
    sendResponse({ ok: true });
    return;
  }
  if (msg.type === 'BONUSSMB_CHECK_STATUS') {
    Promise.resolve(checkStatusGeneric(msg.payload || {})).then(sendResponse);
    return true;
  }
  if (msg.type === 'BONUSSMB_COUNT_CLAIMS') {
    Promise.resolve(countUserClaims(msg.payload || {})).then(sendResponse);
    return true;
  }
  if (msg.type !== 'BONUSSMB_FILL_TICKET') return;
  Promise.resolve(fillTicket(msg.payload || {})).then(sendResponse);
  return true;
});

// ===== COUNT USER CLAIMS ON HISTORY PAGE =====
async function countUserClaims(payload) {
  const userId = String(payload.userId || '').trim().toLowerCase();
  if (!userId) return { ok: false, error: 'userId kosong', count: 0 };

  try {
    // Ensure we are on the history page
    if (!location.href.includes('history')) {
      return { ok: false, error: 'Bukan halaman history', count: 0 };
    }

    await sleep(300);

    // Find search input
    let searchInput = document.querySelector('input[placeholder*="Search"]') ||
                      document.querySelector('input[type="text"]') ||
                      document.querySelector('input[name="search"]');

    if (!searchInput) {
      // Try fallback: search all visible inputs
      const inputs = Array.from(document.querySelectorAll('input')).filter(i => isVisible(i) && i.type !== 'hidden');
      searchInput = inputs[0] || null;
    }

    if (searchInput) {
      // Search by userId
      setNativeValue(searchInput, '');
      searchInput.dispatchEvent(new Event('input', { bubbles: true }));
      await sleep(50);

      setNativeValue(searchInput, userId);
      searchInput.dispatchEvent(new Event('input', { bubbles: true }));
      searchInput.dispatchEvent(new Event('change', { bubbles: true }));
      searchInput.focus();

      // Trigger search
      const searchBtn = document.querySelector('button.search-btn') ||
                        Array.from(document.querySelectorAll('button')).find(b => {
                          const t = b.textContent.toLowerCase();
                          return t.includes('search') || t.includes('cari');
                        });

      if (searchBtn) {
        searchBtn.click();
      } else {
        ['keydown', 'keypress', 'keyup'].forEach(et => {
          searchInput.dispatchEvent(new KeyboardEvent(et, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
        });
      }

      await sleep(800);
    }

    // Count rows that match the userId
    const allRows = Array.from(document.querySelectorAll('tr, [role="row"], .table-row, .ant-table-row'));
    let count = 0;
    const matchedTxIds = [];

    for (const row of allRows) {
      const rowText = String(row.innerText || '').toLowerCase();
      // Skip header rows
      if (row.querySelector('th')) continue;
      // Check if userId appears in this row
      if (rowText.includes(userId)) {
        count++;
        // Try to extract txId from the row
        const cells = Array.from(row.querySelectorAll('td'));
        for (const cell of cells) {
          const txt = cell.innerText.trim();
          // Transaction IDs are typically long numeric strings
          if (/^\d{10,}$/.test(txt.replace(/\s/g, ''))) {
            matchedTxIds.push(txt.replace(/\s/g, ''));
            break;
          }
        }
      }
    }

    // Also check for pagination info (e.g., "out of 15")
    const paginationInfo = Array.from(document.querySelectorAll('div, span, p')).find(el => {
      const t = el.innerText || '';
      return /out of \d+/i.test(t) || /total[:\s]*(\d+)/i.test(t);
    });

    let totalFromPagination = null;
    if (paginationInfo) {
      const m = paginationInfo.innerText.match(/out of (\d+)/i) || paginationInfo.innerText.match(/total[:\s]*(\d+)/i);
      if (m && m[1]) totalFromPagination = parseInt(m[1], 10);
    }

    // Use pagination total if search was by userId, otherwise use row count
    const finalCount = (totalFromPagination !== null && searchInput) ? totalFromPagination : count;

    console.log(`[BonusScatter] Claim count for ${userId}: ${finalCount} (rows: ${count}, pagination: ${totalFromPagination})`);
    return { ok: true, count: finalCount, txIds: matchedTxIds };
  } catch (e) {
    console.error('[BonusScatter] countUserClaims error:', e);
    return { ok: false, error: e.message || 'unknown', count: 0 };
  }
}
