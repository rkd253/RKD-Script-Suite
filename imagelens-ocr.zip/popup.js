// popup.js – Shortcut recorder + activate

const DEFAULT_SHORTCUT = { ctrl: false, alt: true, shift: true, meta: false, key: 'I' };

let currentShortcut = DEFAULT_SHORTCUT;
let isRecording = false;

const btnActivate  = document.getElementById('btnActivate');
const btnRecord    = document.getElementById('btnRecord');
const recordText   = document.getElementById('recText');
const recordIcon   = document.getElementById('recIcon');
const display      = document.getElementById('shortcutDisplay');
const toast        = document.getElementById('alert');

// ── Load saved shortcut ──────────────────────────────────────────────────
chrome.storage.sync.get('shortcut', (data) => {
  currentShortcut = data.shortcut || DEFAULT_SHORTCUT;
  renderShortcut(currentShortcut);
});

// ── Activate OCR on current tab ──────────────────────────────────────────
btnActivate.addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.id) {
    chrome.runtime.sendMessage({ type: 'ACTIVATE_OCR_TAB' });
    window.close();
  }
});

// ── Shortcut recorder ────────────────────────────────────────────────────
btnRecord.addEventListener('click', () => {
  if (isRecording) { stopRecording(false); return; }
  startRecording();
});

function startRecording() {
  isRecording = true;
  btnRecord.classList.add('recording');
  recordIcon.textContent = '🔴';
  recordText.textContent = 'Tekan kombinasi tombol... (Esc = batal)';
  document.addEventListener('keydown', onRecordKey, true);
}

function stopRecording(saved) {
  isRecording = false;
  btnRecord.classList.remove('recording');
  recordIcon.textContent = '⌨️';
  recordText.textContent = saved ? '✅ Shortcut tersimpan!' : 'Klik untuk ganti shortcut';
  document.removeEventListener('keydown', onRecordKey, true);
  if (saved) setTimeout(() => { recordText.textContent = 'Klik untuk ganti shortcut'; }, 2000);
}

function onRecordKey(e) {
  e.preventDefault();
  e.stopPropagation();

  // Esc = cancel
  if (e.key === 'Escape' && !e.ctrlKey && !e.altKey && !e.shiftKey) {
    stopRecording(false);
    return;
  }

  // Ignore modifier-only presses
  const isModOnly = ['Control','Shift','Alt','Meta','CapsLock','Tab'].includes(e.key);
  if (isModOnly) return;

  // Must have at least one modifier
  if (!e.ctrlKey && !e.altKey && !e.shiftKey && !e.metaKey) {
    showToast('⚠️ Harus pakai modifier (Ctrl / Alt / Shift)', 'err');
    return;
  }

  const shortcut = {
    ctrl:  e.ctrlKey,
    alt:   e.altKey,
    shift: e.shiftKey,
    meta:  e.metaKey,
    key:   e.key.toUpperCase(),
  };

  currentShortcut = shortcut;
  chrome.storage.sync.set({ shortcut }, () => {
    renderShortcut(shortcut);
    stopRecording(true);
  });
}

// ── Render shortcut chips ────────────────────────────────────────────────
function renderShortcut(s) {
  display.innerHTML = '';
  const parts = [];
  if (s.ctrl)  parts.push('Ctrl');
  if (s.alt)   parts.push('Alt');
  if (s.shift) parts.push('Shift');
  if (s.meta)  parts.push('Meta');
  parts.push(s.key);

  parts.forEach((p, i) => {
    const chip = document.createElement('span');
    chip.className = 'key';
    chip.textContent = p;
    display.appendChild(chip);
    if (i < parts.length - 1) {
      const sep = document.createElement('span');
      sep.className = 'key-sep';
      sep.textContent = '+';
      display.appendChild(sep);
    }
  });
}

// ── Toast ────────────────────────────────────────────────────────────────
function showToast(msg, type) {
  toast.textContent = msg;
  const typeClass = type === 'err' ? 'err' : 'ok';
  toast.className = `alert show ${typeClass}`;
  setTimeout(() => { toast.className = 'alert'; }, 3000);
}
