// content.js – ImageLens OCR Content Script
(function () {
  'use strict';

  // Default shortcut
  const DEFAULT_SHORTCUT = { ctrl: false, alt: true, shift: true, meta: false, key: 'I' };

  let ocrActive = false;
  let overlay = null;
  let hintEl = null;
  let toast = null;
  let toastTimer = null;
  let tesseractWorker = null;
  let currentShortcut = DEFAULT_SHORTCUT;

  // ─── Load shortcut from storage ──────────────────────────────────────────
  function loadShortcut() {
    chrome.storage.sync.get('shortcut', (data) => {
      if (data.shortcut) currentShortcut = data.shortcut;
    });
  }

  loadShortcut();

  // Re-load if storage changes (user updated from popup)
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.shortcut) {
      currentShortcut = changes.shortcut.newValue;
    }
  });

  // ─── Listen for messages from background/popup ────────────────────────────
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "TOGGLE_OCR_MODE") toggleOCRMode();
    if (msg.type === "PROCESS_IMAGE_URL") processImageUrl(msg.srcUrl);
  });

  // ─── Global keydown: match shortcut ──────────────────────────────────────
  document.addEventListener("keydown", (e) => {
    if (!currentShortcut) return;
    const s = currentShortcut;
    const match =
      e.ctrlKey === s.ctrl &&
      e.altKey === s.alt &&
      e.shiftKey === s.shift &&
      e.metaKey === s.meta &&
      e.key.toUpperCase() === s.key.toUpperCase();

    if (match && !ocrActive) {
      e.preventDefault();
      e.stopPropagation();
      activateOCR();
    } else if (e.key === "Escape" && ocrActive) {
      deactivateOCR();
    }
  }, true);

  // ─── Toggle ───────────────────────────────────────────────────────────────
  function toggleOCRMode() {
    ocrActive ? deactivateOCR() : activateOCR();
  }

  // ─── Activate ─────────────────────────────────────────────────────────────
  function activateOCR() {
    ocrActive = true;
    createOverlay();
    showHint("🖐️ DOMAIN EXPANSION: SELECT AREA  ·  Esc to Cancel");
    document.addEventListener("mousedown", onMouseDown, true);
    document.addEventListener("dragstart", preventDrag, true);
  }

  function preventDrag(e) {
    if (ocrActive) {
      e.preventDefault();
      e.stopPropagation();
    }
  }

  // ─── Deactivate ───────────────────────────────────────────────────────────
  function deactivateOCR() {
    ocrActive = false;
    removeOverlay();
    removeHint();
    if (selectionBox) { selectionBox.remove(); selectionBox = null; }
    document.removeEventListener("mousedown", onMouseDown, true);
    document.removeEventListener("mousemove", onSelectionMove, true);
    document.removeEventListener("mouseup", onSelectionUp, true);
    document.removeEventListener("dragstart", preventDrag, true);
  }

  // ─── Area Selection ───────────────────────────────────────────────────────
  let isSelecting = false;
  let startX = 0, startY = 0;
  let selectionBox = null;

  function onMouseDown(e) {
    if (e.button !== 0) return; // Only left click
    e.preventDefault(); e.stopPropagation();
    isSelecting = true;
    startX = e.clientX;
    startY = e.clientY;

    if (!selectionBox) {
      selectionBox = document.createElement("div");
      selectionBox.className = "imagelens-selection-box";
      document.body.appendChild(selectionBox);
    }

    updateSelectionBox(e.clientX, e.clientY);
    document.addEventListener("mousemove", onSelectionMove, true);
    document.addEventListener("mouseup", onSelectionUp, true);
  }

  function onSelectionMove(e) {
    if (!isSelecting) return;
    e.preventDefault(); e.stopPropagation();
    updateSelectionBox(e.clientX, e.clientY);
  }

  function updateSelectionBox(curX, curY) {
    if (!selectionBox) return;
    const left = Math.min(startX, curX);
    const top = Math.min(startY, curY);
    const width = Math.abs(startX - curX);
    const height = Math.abs(startY - curY);
    
    selectionBox.style.left = left + "px";
    selectionBox.style.top = top + "px";
    selectionBox.style.width = width + "px";
    selectionBox.style.height = height + "px";
  }

  async function onSelectionUp(e) {
    if (!isSelecting) return;
    isSelecting = false;
    e.preventDefault(); e.stopPropagation();
    document.removeEventListener("mousemove", onSelectionMove, true);
    document.removeEventListener("mouseup", onSelectionUp, true);

    const rect = selectionBox.getBoundingClientRect();
    deactivateOCR(); // Removes UI

    if (rect.width > 5 && rect.height > 5) {
      await captureAndCrop(rect);
    } else {
      showToast("⚠️ BINDING VOW: AREA TOO SMALL", "warn");
    }
  }

  // ─── Screen Capture & Crop ────────────────────────────────────────────────
  async function captureAndCrop(rect) {
    showToast("📸 CAPTURING DOMAIN...", "loading");
    
    // Tunggu sedikit agar UI highlight/overlay benar-benar hilang dari DOM sebelum screenshot
    await new Promise(r => setTimeout(r, 50));

    try {
      const response = await new Promise(resolve => {
        chrome.runtime.sendMessage({ type: "CAPTURE_SCREEN" }, resolve);
      });

      if (!response || !response.dataUrl) {
        throw new Error(response?.error || "Gagal mendapatkan screenshot dari background");
      }

      const croppedDataUrl = await cropImage(response.dataUrl, rect);
      await processImageUrl(croppedDataUrl);
    } catch (err) {
      console.error("[ImageLens]", err);
      showToast("❌ Error: " + (err.message || "Gagal menangkap layar"), "error");
    }
  }

  function cropImage(dataUrl, rect) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const ctx = canvas.getContext("2d");
        const dpr = window.devicePixelRatio || 1;

        canvas.width = rect.width * dpr;
        canvas.height = rect.height * dpr;

        ctx.drawImage(
          img,
          rect.left * dpr, rect.top * dpr, rect.width * dpr, rect.height * dpr,
          0, 0, canvas.width, canvas.height
        );
        resolve(canvas.toDataURL("image/png"));
      };
      img.onerror = reject;
      img.src = dataUrl;
    });
  }

  async function processImageUrl(src) {
    showToast("🔮 ANALYZING CURSED ENERGY...", "loading");
    try {
      if (!tesseractWorker) await initTesseract();

      if (!src.startsWith("data:") && !src.startsWith("blob:")) {
        try { src = await fetchAsDataURL(src); } catch { /* ignore */ }
      }

      const { data: { text } } = await tesseractWorker.recognize(src);
      
      // Bersihkan teks: 
      // 1. Hapus titik/koma yang menempel pada akhir angka jika diikuti spasi/baris baru (halusinasi OCR)
      let cleaned = text.replace(/(\d)[.,]+(\s|$)/g, '$1$2');
      
      // 2. Rapikan baris
      cleaned = cleaned
        .split('\n')
        .map(line => line.trim())
        .filter(line => line.length > 0)
        .join('\n');

      if (!cleaned) { showToast("❌ VOID: NO TEXT FOUND", "warn"); return; }

      // 3. Robust Copy to Clipboard
      try {
        await copyToClipboard(cleaned);
        showToast(`💠 TECHNIQUE SUCCESS: COPIED! (${cleaned.length} ch)`, "success");
      } catch (copyErr) {
        console.warn("[ImageLens] Clipboard API failed, showing modal fallback", copyErr);
        showToast("⚠️ COPIED MANUALLY FROM MODAL", "info");
      }
      
      // Tampilkan Modal Hasil (Always show so user can see what was captured)
      showResultModal(cleaned);

    } catch (err) {
      console.error("[ImageLens]", err);
      showToast("❌ Error: " + (err.message || "Gagal"), "error");
    }
  }

  // Robust Copy Fallback
  async function copyToClipboard(text) {
    if (navigator.clipboard && window.isSecureContext) {
      try {
        await navigator.clipboard.writeText(text);
        return;
      } catch (err) {
        // Fallback to execCommand if clipboard fails (e.g. focus issue)
      }
    }
    
    // Legacy fallback
    const textArea = document.createElement("textarea");
    textArea.value = text;
    textArea.style.position = "fixed";
    textArea.style.left = "-9999px";
    textArea.style.top = "0";
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    try {
      document.execCommand('copy');
    } catch (err) {
      throw new Error("Unable to copy");
    }
    document.body.removeChild(textArea);
  }

  // ─── Modal Hasil ──────────────────────────────────────────────────────────
  function showResultModal(text) {
    // Buat overlay modal
    const overlay = document.createElement("div");
    overlay.className = "imagelens-result-overlay";
    
    const modal = document.createElement("div");
    modal.className = "imagelens-result-modal";
    
    // Header
    const header = document.createElement("div");
    header.className = "imagelens-modal-header";
    header.innerHTML = `
      <h3 class="imagelens-modal-title">🤞 DOMAIN EXPANSION: RESULT</h3>
      <button class="imagelens-modal-close">&times;</button>
    `;
    
    // Event listeners untuk menutup modal
    const closeFn = () => {
      overlay.remove();
      window.removeEventListener("keydown", escCloseFn, true);
    };

    const escCloseFn = (e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        closeFn();
      }
    };

    // Body (Textarea agar bisa diedit/disalin ulang)
    const body = document.createElement("div");
    body.className = "imagelens-modal-body";
    const textarea = document.createElement("textarea");
    textarea.className = "imagelens-modal-textarea";
    textarea.value = text;
    
    // Direct Esc listener on textarea
    textarea.onkeydown = (e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        closeFn();
      }
    };
    
    body.appendChild(textarea);
    
    // Footer (Tombol Tutup)
    const footer = document.createElement("div");
    footer.className = "imagelens-modal-footer";
    const closeBtn = document.createElement("button");
    closeBtn.className = "imagelens-btn imagelens-btn-primary";
    closeBtn.textContent = "✖ CLOSE DOMAIN";
    footer.appendChild(closeBtn);
    
    modal.appendChild(header);
    modal.appendChild(body);
    modal.appendChild(footer);
    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    // Auto-focus textarea for immediate manual copy or Esc
    setTimeout(() => textarea.focus(), 100);

    window.addEventListener("keydown", escCloseFn, true);
    header.querySelector(".imagelens-modal-close").onclick = closeFn;
    closeBtn.onclick = closeFn;
    overlay.onclick = (e) => { if (e.target === overlay) closeFn(); };
  }

  async function fetchAsDataURL(url) {
    const resp = await fetch(url, { mode: "cors" });
    const blob = await resp.blob();
    return new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(r.result);
      r.onerror = rej;
      r.readAsDataURL(blob);
    });
  }

  // ─── Tesseract ────────────────────────────────────────────────────────────
  async function initTesseract() {
    showToast("📦 Memuat mesin OCR...", "loading");

    const workerPath = chrome.runtime.getURL("libs/worker.min.js");
    // Gunakan fetch dan buat Blob URL agar tidak terkena error CORS/Cross-Origin Worker
    const workerBlob = await fetch(workerPath).then(r => r.blob());
    const workerBlobUrl = URL.createObjectURL(workerBlob);

    tesseractWorker = await Tesseract.createWorker("eng", 1, {
      workerPath: workerBlobUrl,
      logger: () => { },
    });
  }

  // ─── UI helpers ───────────────────────────────────────────────────────────
  function createOverlay() {
    overlay = document.createElement("div");
    overlay.className = "imagelens-overlay";
    document.body.appendChild(overlay);
  }
  function removeOverlay() { if (overlay) { overlay.remove(); overlay = null; } }

  function showHint(msg) {
    removeHint();
    hintEl = document.createElement("div");
    hintEl.className = "imagelens-hint";
    hintEl.textContent = msg;
    document.body.appendChild(hintEl);
  }
  function removeHint() { if (hintEl) { hintEl.remove(); hintEl = null; } }

  function showToast(msg, type = "info") {
    if (toast) toast.remove();
    toast = document.createElement("div");
    toast.className = `imagelens-toast imagelens-toast--${type}`;
    toast.textContent = msg;
    document.body.appendChild(toast);
    requestAnimationFrame(() => toast.classList.add("imagelens-toast--visible"));
    if (type !== "loading") {
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => {
        if (toast) { toast.classList.remove("imagelens-toast--visible"); setTimeout(() => { toast?.remove(); toast = null; }, 400); }
      }, type === "success" ? 3000 : 4000);
    }
  }

})();
