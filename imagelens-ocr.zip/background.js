// background.js – Service Worker for ImageLens OCR

// Create Context Menu on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "imagelens-ocr-context",
    title: "Salin teks dari gambar (OCR)",
    contexts: ["image"]
  });
});

// Handle Context Menu click
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "imagelens-ocr-context" && tab && tab.id) {
    chrome.tabs.sendMessage(tab.id, { 
      type: "PROCESS_IMAGE_URL", 
      srcUrl: info.srcUrl 
    }).catch(() => console.warn("ImageLens: Content script tidak berjalan di halaman ini."));
  }
});

// Listen for activation message from popup and content scripts
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "ACTIVATE_OCR_TAB") {
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      if (tab?.id) {
        chrome.tabs.sendMessage(tab.id, { type: "TOGGLE_OCR_MODE" })
          .catch(() => console.warn("ImageLens: Content script tidak berjalan di halaman ini."));
      }
    });
  } else if (msg.type === "CAPTURE_SCREEN") {
    chrome.tabs.captureVisibleTab(sender.tab.windowId, { format: "png" })
      .then(dataUrl => sendResponse({ dataUrl }))
      .catch(err => {
        console.error("ImageLens Capture failed:", err);
        sendResponse({ error: err.message });
      });
    return true; // Keep message channel open for async response
  }
  return true;
});
