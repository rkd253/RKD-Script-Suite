function normalizeLine(line) {
  return String(line || '').trim();
}

function normalizeUserId(raw) {
  const s = String(raw || '').trim();
  if (!s) return '';
  return s.split(/\s+/)[0];
}

function normalizeTicketCode(raw) {
  return String(raw || '').replace(/\s+/g, '').trim();
}

function extractTxFromOcrText(rawText) {
  if (!rawText) return null;
  
  // Normalisasi karakter OCR yang sering salah membaca angka
  const text = String(rawText)
    .replace(/[Oo]/g, '0')
    .replace(/[Il|]/g, '1')
    .replace(/[Zz]/g, '2')
    .replace(/[Ss$]/g, '5')
    .replace(/[Bb]/g, '8');

  // 1. Cari pola 19 digit yang diawali '20' (PG Soft / Pragmatic mobile format standar)
  const allPureDigits = text.replace(/[^0-9]/g, '');
  const match20 = allPureDigits.match(/20\d{16,18}/g);
  if (match20 && match20.length > 0) {
    for (const cand of match20) {
      if (cand.length >= 19) return cand.slice(0, 19);
    }
  }

  // 2. Direct single-token match 16-20 digits
  const cleaned = text.replace(/[^0-9\s]/g, ' ');
  const directMatches = cleaned.match(/\b\d{16,20}\b/g) || [];
  if (directMatches.length > 0) {
    const best = directMatches.find(d => d.startsWith('20') && d.length === 19) || directMatches[0];
    return best.length > 19 ? best.slice(0, 19) : best;
  }

  // 3. Multi-line split match (misal baris 1: 9 digit, baris 2: 10 digit di mobile UI)
  const numbers = cleaned.split(/\s+/).filter(n => n.length >= 3 && n.length <= 15);
  for (let i = 0; i < numbers.length - 1; i++) {
    const combined = numbers[i] + numbers[i + 1];
    if (combined.length >= 18 && combined.length <= 20 && combined.startsWith('20')) {
      return combined.slice(0, 19);
    }
  }
  for (let i = 0; i < numbers.length - 2; i++) {
    const combined3 = numbers[i] + numbers[i + 1] + numbers[i + 2];
    if (combined3.length >= 18 && combined3.length <= 20 && combined3.startsWith('20')) {
      return combined3.slice(0, 19);
    }
  }

  // 4. Fallback: ambil deretan 16-19 angka apapun yang diawali 20
  const m = allPureDigits.match(/20\d{14,17}/);
  if (m) {
    return m[0];
  }

  return null;
}

function parseBulk(text) {
  const lines = String(text || '')
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  const items = [];
  for (const line of lines) {
    const parts = line
      .split(',')
      .map((p) => p.trim())
      .filter((p) => p.length > 0);
    const userIdRaw = String(parts[0] || '').trim();
    const userId = normalizeUserId(userIdRaw);
    const transactionId = normalizeTicketCode(parts[1] || '');
    const betting = parts[2];
    if (!userId || !transactionId) continue;
    const isTS = userIdRaw.toLowerCase().endsWith(' ts');
    const item = { userId, userIdRaw, transactionId };
    if (isTS) item.isTS = true;
    if (typeof betting !== 'undefined' && betting !== '') item.betting = betting;
    items.push(item);
  }
  return items;
}

function parseHeaderBlock(text) {
  const raw = String(text || '').trim();
  if (!raw) return null;
  const lines = raw
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);
  if (lines.length === 0) return null;

  const canonicalMap = {
    'x-access-token': 'X-Access-Token',
    'x-agent-pkid': 'X-Agent-Pkid',
    'x-agent-role': 'X-Agent-Role',
    'x-agent-suid': 'X-Agent-Suid',
    'x-agent-user': 'X-Agent-User',
    'x-agent-userid': 'X-Agent-UserId',
  };

  const out = {};

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    if (line.includes(':')) {
      const idx = line.indexOf(':');
      const kRaw = line.slice(0, idx).trim();
      const v = line.slice(idx + 1).trim();
      const k = canonicalMap[String(kRaw).toLowerCase()] || null;
      if (k && v) out[k] = v;
      continue;
    }

    const parts = line.split(/\s+/);
    if (parts.length >= 2) {
      const kRaw = parts[0].trim();
      const v = parts.slice(1).join(' ').trim();
      const k = canonicalMap[String(kRaw).toLowerCase()] || null;
      if (k && v) {
        out[k] = v;
        continue;
      }
    }

    const key = canonicalMap[String(line).toLowerCase()] || null;
    if (!key) continue;
    const value = lines[i + 1];
    if (!value) continue;
    const isHeaderKey = !!canonicalMap[String(value).toLowerCase()];
    if (isHeaderKey) continue;
    out[key] = value;
    i++;
  }

  return Object.keys(out).length ? out : null;
}

function buildConfig() {
  const cfg = {};
  const executorName = normalizeLine(el.executorName.value);
  const adminUrl = normalizeLine(el.adminUrl.value);
  const startDate = normalizeLine(el.startDate.value);
  const endDate = normalizeLine(el.endDate.value);
  const yesterdayDate = el.yesterdayDate ? normalizeLine(el.yesterdayDate.value) : '';
  const agentHeaders = String(el.agentHeaders.value || '');
  const todayDate = todayISO();

  if (executorName) cfg.executorName = executorName;
  if (adminUrl) cfg.adminUrl = adminUrl;
  if (startDate) cfg.startDate = startDate;
  if (endDate) cfg.endDate = endDate;
  if (yesterdayDate) cfg.yesterdayDate = yesterdayDate;
  cfg.todayDate = todayDate;
  cfg.processMode = 'auto';

  const parsed = parseHeaderBlock(agentHeaders);
  if (parsed) cfg.agentHeaders = parsed;

  return cfg;
}
